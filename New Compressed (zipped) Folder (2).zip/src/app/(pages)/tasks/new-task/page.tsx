"use client";

import React from "react";
import {
  Box,
  Button,
  Grid,
  Typography,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

type CategoryItem = { id: number; label: string };

const NewTask: React.FC = () => {
  const [categorie, setCategorie] = useState<string>("");
  const [categories, setCategories] = useState<CategoryItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const router = useRouter();
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    async function loadCategories() {
      setIsLoading(true);
      try {
        const res = await fetch("/api/tasks/categories?type=task");
        if (!res.ok) {
          setCategories([]);
          return;
        }
        const data = await res.json();

        // Construction simple et explicite
        const list: CategoryItem[] = [];
        if (data && Array.isArray(data.categories)) {
          for (let i = 0; i < data.categories.length; i++) {
            const x = data.categories[i];
            const item: CategoryItem = { id: x.id, label: x.label };
            list.push(item);
          }
        }
        setCategories(list);
      } catch {
        setCategories([]);
      }
      setIsLoading(false);
    }

    loadCategories();
  }, []);

  async function onSubmit(data: any) {
    try {
      const body = {
        title: data.title,
        description: data.description,
        categorie: data.categorie,
        demandePour: data.demandePour || "",
        informationsAdditionnelles: data.informationsAdditionnelles || "",
      };

      const response = await fetch("/api/tasks/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        alert(error.error || "Erreur lors de la création.");
        return;
      }

      await response.json();
      router.push("/tasks");
    } catch (error) {
      alert("Erreur réseau.");
    }
  }

  return (
    <Box>
      <Typography variant="h4" mb={3}>
        Nouvelle demande
      </Typography>

      <form onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          <Grid size={{ xs: 12, md: 6 }}>
            <Controller
              name="title"
              control={control}
              rules={{ required: "Le titre est requis" }}
              render={({ field }) => (
                <TextField
                  {...field}
                  fullWidth
                  label="Titre"
                  error={!!errors.title}
                />
              )}
            />
          </Grid>

          <Grid size={{ xs: 12 }}>
            <Controller
              name="demandePour"
              control={control}
              rules={{ required: "Ce champ est requis" }}
              render={({ field }) => (
                <TextField
                  {...field}
                  fullWidth
                  label="Demande pour"
                  error={!!errors.demandePour}
                />
              )}
            />
          </Grid>

          <Grid size={{ xs: 12 }}>
            <Controller
              name="description"
              control={control}
              rules={{ required: "La description est requise" }}
              render={({ field }) => (
                <TextField
                  {...field}
                  fullWidth
                  multiline
                  minRows={4}
                  label="Description"
                  error={!!errors.description}
                />
              )}
            />
          </Grid>

          <Grid size={{ xs: 12, md: 6 }}>
            <Controller
              name="categorie"
              control={control}
              rules={{ required: "La catégorie est requise" }}
              render={({ field }) => (
                <FormControl fullWidth error={!!errors.categorie}>
                  <InputLabel>Catégorie</InputLabel>
                  <Select
                    label="Catégorie"
                    value={categorie}
                    onChange={(e) => setCategorie(String(e.target.value))}
                  >
                    {categories.length === 0 ? (
                      <MenuItem value="" disabled>
                        Aucune catégorie
                      </MenuItem>
                    ) : null}
                    {categories.map((c) => (
                      <MenuItem key={c.id} value={c.label}>
                        {c.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              )}
            />
          </Grid>

          <Grid size={{ xs: 12 }}>
            <Controller
              name="informationsAdditionnelles"
              control={control}
              render={({ field }) => (
                <TextField
                  {...field}
                  fullWidth
                  multiline
                  minRows={3}
                  label="Informations additionnelles"
                />
              )}
            />
            <Typography variant="caption" color="text.secondary" mt={1}>
              Pour la création d’un utilisateur, indiquez l’email privé ici.
            </Typography>
          </Grid>

          <Grid size={{ xs: 12 }}>
            <Button type="submit" variant="contained" color="primary">
              Créer la demande
            </Button>
          </Grid>
        </Grid>
      </form>
    </Box>
  );
};

export default NewTask;
